# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'd0b12f06099e084eef8d8fa9a5c98133df96667c7d5869166967c8d0ff944b86da323424f9b93768b87356ac3ff9adc55e7ae2693465d695581103f363c53379'